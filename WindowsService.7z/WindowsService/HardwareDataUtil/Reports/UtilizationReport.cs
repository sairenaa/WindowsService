﻿using System;
using HardwareDataUtil.DB;
using System.IO;

namespace HardwareDataUtil.Reports
{
    public class UtilizationReport
    {
        private readonly string filepath = "./report.csv";
        private string FileContent {  get; set; }

        public void Create()
        {
            FileContent = "Value,Create Date,Model,Additonal Info\n";

            // Read data from database
            var databaseData = Database.ReadReportData();

            if (databaseData != null)
            {
                foreach (ReportDatabaseDataModel result in databaseData)
                {
                    FileContent += string.Join(",", result.Value.ToString(), result.CreateDate.ToString(), result.Model, result.AdditionalInfo) + "\n";
                }

                // Save data in csv file
                try
                {
                    File.WriteAllText(filepath, FileContent);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Cannot write report in a file! Message: " + ex.Message);
                }

            }
            else
            {
                Console.WriteLine("Error in creating report, due to missing data from database!");
            }
        }
    }
}
