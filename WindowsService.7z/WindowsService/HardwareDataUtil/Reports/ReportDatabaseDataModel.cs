﻿using System;

namespace HardwareDataUtil.Reports
{
    public class ReportDatabaseDataModel
    {
        public int Value { get; set; }
        public DateTime CreateDate { get; set; }
        public string Model { get; set; }
        public string AdditionalInfo { get; set; }
    }
}
