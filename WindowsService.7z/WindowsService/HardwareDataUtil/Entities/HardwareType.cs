﻿using System;
using System.Collections.Generic;
using System.Management;

namespace HardwareDataUtil.Entities
{
    public class HardwareType
    {
        public int Id { get; set; }
        public string Model { get; set; }
        public string AdditionalInfo { get; set; }

        public static List<HardwareType> Init()
        {
            var hardwareTypes = new List<HardwareType>();

            // Query information about CPU
            var processorSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_Processor");
            string cpuName = "", processorId = "", cpuType = "CPU";

            foreach (var processor in processorSearcher.Get())
            {
                cpuName = processor["Name"].ToString();
                processorId = processor["ProcessorID"].ToString();

            }

            hardwareTypes.Add(new HardwareType { 
                Model = cpuName,
                AdditionalInfo = $"{cpuType}; Processor ID: {processorId}"
            });

            // Query information about Memory
            var memorySearcher = new ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMemory");
            string memoryName = "", memoryType = "Memory";
            List<string> memorySerialNumbers = new List<string>();

            foreach (var memory in memorySearcher.Get())
            {
                memoryName = memory["Name"].ToString();
                memorySerialNumbers.Add(memory["SerialNumber"].ToString());
            }

            hardwareTypes.Add(new HardwareType
            {
                Model = memoryName,
                AdditionalInfo = $"{memoryType}; Serial Number: {string.Join(";", memorySerialNumbers)}"
            });

            // Query information about Disk
            var diskSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive");
            string diskName = "", diskType = "Disk", diskSerialNumber = "";

            foreach(var disk in diskSearcher.Get())
            {
                diskName = disk["Model"].ToString();
                diskSerialNumber = disk["SerialNumber"].ToString();

            }

            hardwareTypes.Add(new HardwareType
            {
                Model = diskName,
                AdditionalInfo = $"{diskType}; Serial Number: {diskSerialNumber}"
            });

            return hardwareTypes;
        }
    }
}
