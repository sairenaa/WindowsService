﻿using System;
using System.Management;
using System.Threading;

namespace HardwareDataUtil.Entities
{
    public class Record
    {
        public int Id { get; set; }
        public int HardwareTypeId { get; set; }
        public int Value { get; set; }
        public DateTime CreateDate { get; set; }

        public static Record GetCpuUtilization(int cpuId)
        {
            var resultRecord = new Record();
            var cpuUsage = 0;
            var managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_PerfFormattedData_PerfOS_Processor WHERE Name='_Total'");

            // Measure twice for more accurate value
            foreach(ManagementObject item in managementObjectSearcher.Get())
            {
                cpuUsage = (int)Convert.ToSingle(item["PercentProcessorTime"]);
            }

            // Add a delay
            Thread.Sleep(1000);

            foreach (ManagementObject item in managementObjectSearcher.Get())
            {
                cpuUsage = (int)Convert.ToSingle(item["PercentProcessorTime"]);
            }

            resultRecord.Value = cpuUsage;
            resultRecord.HardwareTypeId = cpuId;
            resultRecord.CreateDate = DateTime.Now;

            Console.WriteLine("CPU utilization obtained.");

            return resultRecord;
        }

        public static Record GetMemoryUtilization(int memoryId)
        {
            var resultRecord = new Record();
            var memoryUsage = 0;
            var totalMemory = 0L;
            var freeMemory = 0L;
            var managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_OperatingSystem");

            foreach(ManagementObject item in managementObjectSearcher.Get())
            {
                totalMemory += Convert.ToInt64(item["TotalVisibleMemorySize"]);
                freeMemory += Convert.ToInt64(item["FreePhysicalMemory"]);

            }

            // Calculate used memory as a percentage
            memoryUsage += (int)(((float)(totalMemory - freeMemory) / totalMemory) * 100);

            resultRecord.Value = memoryUsage;
            resultRecord.HardwareTypeId = memoryId;
            resultRecord.CreateDate = DateTime.Now;

            Console.WriteLine("Memory utilization obtained.");

            return resultRecord;
        }

        public static Record GetDiskUtilization(int diskId)
        {
            var resultRecord = new Record();
            var diskUsage = 0;
            var totalSize = 0L;
            var freeSpace = 0L;
            var managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_LogicalDisk");

            foreach (ManagementObject item in managementObjectSearcher.Get())
            {
                totalSize += Convert.ToInt64(item["Size"]);
                freeSpace += Convert.ToInt64(item["FreeSpace"]);

            }

            // Calculate used space as a percentage
            diskUsage += (int)(((float)(totalSize - freeSpace) / totalSize) * 100);

            resultRecord.Value = diskUsage;
            resultRecord.HardwareTypeId = diskId;
            resultRecord.CreateDate = DateTime.Now;

            Console.WriteLine("Disk utilization obtained.");

            return resultRecord;
        }
    }

}
