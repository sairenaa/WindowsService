﻿using HardwareDataUtil.DB;
using HardwareDataUtil.Entities;
using HardwareDataUtil.Reports;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Threading;

namespace HardwareDataUtil
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var hardwareTypes = new List<HardwareType>();
            // Get interval minutes from config file
            var intervalMinutes = ConfigurationManager.AppSettings["intervalMinutes"];
            var intervalMiliseconds = Convert.ToInt32(intervalMinutes) * 60 * 1000;
            
            // Create DB
            Database.Create();

            // Get needed information for harwdare types
            hardwareTypes = HardwareType.Init();
            // Insert hardware types into DB
            Database.InsertHardwareTypes(hardwareTypes);

            // Set up timer and interval for recording
            var Timer = new Timer(TimerCallback, null, 0, intervalMiliseconds);

            // Create Report
            // var report = new UtilizationReport();
            // report.Create();

            // Keep the application running
            Console.WriteLine("Press any key to exit.");
            Console.ReadLine();
        }

        static void TimerCallback(object state)
        {
            MonitorAndRecordUtilization();
        }

        static void MonitorAndRecordUtilization()
        {
            var records = new List<Record>();
            int cpuId, memoryId, diskId;

            try
            {
                cpuId = Database.GetHardwareTypeId("CPU");
                memoryId = Database.GetHardwareTypeId("Memory");
                diskId = Database.GetHardwareTypeId("Disk");
                
                // Record CPU utilization
                records.Add(Record.GetCpuUtilization(cpuId));
                // Record Memory utilization
                records.Add(Record.GetMemoryUtilization(memoryId));
                // Record Disk utilization
                records.Add(Record.GetDiskUtilization(diskId));

                // Save records in DB
                Database.InsertRecords(records);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }
    }
}
