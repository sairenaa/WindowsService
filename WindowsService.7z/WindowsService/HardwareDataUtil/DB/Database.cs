﻿using System;
using System.Data.SQLite;
using System.IO;
using Dapper;
using HardwareDataUtil.Reports;
using System.Collections.Generic;
using System.Linq;
using HardwareDataUtil.Entities;

namespace HardwareDataUtil.DB
{
    public class Database
    {
        private static readonly string filename = "./hardware_data.sqlite";
        private static SQLiteConnection Connection { get; set; }

        // Creates database if not exists
        public static void Create()
        {
            try
            {
                if (!File.Exists(filename))
                {
                    SQLiteConnection.CreateFile(filename);

                    Console.WriteLine("Created DB!");

                    // Create and open connection to create tables
                    Connect();
                    CreateTables();
                }
                else
                {
                    // DB exists, create and open connection
                    Connect();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error creating or accessing the database file! Message: " + e.Message);
            }
        }

        // Creates new SQLite connection and opens it
        public static void Connect()
        {
            try
            {
                Connection = new SQLiteConnection($"Data Source={filename};Version=3;");
                Connection.Open();

                Console.WriteLine("Connected to database.");

            }
            catch (Exception e)
            {
                Console.WriteLine("Error in connecting to database. Message: " + e.Message);
            }
        }

        // Wrapper method for executing non-queries
        public static void ExecuteNonQuery(string command, object parameters = null)
        {
            try
            {
                if( parameters == null)
                {
                    Connection.Execute(command);
                }
                else
                {
                    Connection.Execute(command, parameters);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error in executing non-query for command: {command}. Message: " + e.Message);
            }
        }

        // Creates tables HardwareTypes and Records
        private static void CreateTables()
        {
            var createHardwareTypesQuery = @"
                CREATE TABLE IF NOT EXISTS HardwareTypes (
                    Id INTEGER NOT NULL PRIMARY KEY,
                    Model VARCHAR(50),
                    AdditionalInfo VARCHAR(255)
                )
            ";

            var createRecordsQuery = @"
                CREATE TABLE IF NOT EXISTS Records (
                    Id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    HardwareTypeId INTEGER NOT NULL,
                    Value INTEGER NOT NULL,
                    CreateDate DATETIME NOT NULL,
                    FOREIGN KEY (HardwareTypeId) REFERENCES HardwareTypes(Id)
                )
            ";

            ExecuteNonQuery(createHardwareTypesQuery);
            ExecuteNonQuery(createRecordsQuery);
        }

        // Inserts hardware types in HardwareTypes table
        public static void InsertHardwareTypes(List<HardwareType> hardwareTypes)
        {
            var insertHardwareTypeQuery = @"
                INSERT INTO HardwareTypes (Model, AdditionalInfo)
                VALUES (@Model, @AdditionalInfo)
            ";

            foreach (HardwareType hardwareType in hardwareTypes)
            {
                ExecuteNonQuery(insertHardwareTypeQuery, hardwareType);
            }
        }

        // Inserts records in Records table
        public static void InsertRecords(List<Record> records)
        {
            var insertRecordQuery = @"
                INSERT INTO Records (HardwareTypeId, Value, CreateDate)
                VALUES (@HardwareTypeId, @Value, @CreateDate)
            ";

            foreach (Record record in records)
            {
                ExecuteNonQuery(insertRecordQuery, record);
            }

            Console.WriteLine("Inserted records in database.");
        }

        // Reads data from database, needed for report
        public static List<ReportDatabaseDataModel> ReadReportData()
        {
            string readQuery = @"
                SELECT Records.Value, Records.CreateDate, HardwareTypes.Model, HardwareTypes.AdditionalInfo
                FROM Records
                JOIN HardwareTypes
                ON Records.HardwareTypeId = HardwareTypes.Id
                ORDER BY Records.CreateDate
            ";

            try
            {
                return Connection.Query<ReportDatabaseDataModel>(readQuery).ToList();
            }
            catch (Exception e)
            {
                Console.WriteLine("Error in reading report data from database. Message: " + e.Message);
                return null;
            }
        }

        // Returns Id from HardwareType table
        // based on type passed as argument
        public static int GetHardwareTypeId(string type)
        {
            var selectQuery = $@"
                SELECT Id
                FROM HardwareTypes
                WHERE AdditionalInfo LIKE '{type}%'
            ";

            try
            {
                int? result = Connection.QueryFirstOrDefault<int>(selectQuery);

                if (result.HasValue)
                {
                    return (int)result;
                }
                else
                {
                    throw new Exception("There is no matching hardware type.");
                }
            }
            catch (Exception e)
            {
                throw new Exception("Error in getting hardwareTypeId. Message: " + e.Message);
            }
        }
    }
}
